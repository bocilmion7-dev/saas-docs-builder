/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as admin from "../admin.js";
import type * as auditLogs from "../auditLogs.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as bakery from "../bakery.js";
import type * as bengkel from "../bengkel.js";
import type * as bomRecipe from "../bomRecipe.js";
import type * as brands from "../brands.js";
import type * as cafeResto from "../cafeResto.js";
import type * as categories from "../categories.js";
import type * as clothing from "../clothing.js";
import type * as customers from "../customers.js";
import type * as expenses from "../expenses.js";
import type * as featureFlags from "../featureFlags.js";
import type * as http from "../http.js";
import type * as kain from "../kain.js";
import type * as landingContent from "../landingContent.js";
import type * as midtrans from "../midtrans.js";
import type * as orders from "../orders.js";
import type * as platformSettings from "../platformSettings.js";
import type * as posShifts from "../posShifts.js";
import type * as products from "../products.js";
import type * as purchaseOrders from "../purchaseOrders.js";
import type * as reports from "../reports.js";
import type * as seed from "../seed.js";
import type * as seedDemo from "../seedDemo.js";
import type * as shipping from "../shipping.js";
import type * as spa from "../spa.js";
import type * as sparepart from "../sparepart.js";
import type * as staff from "../staff.js";
import type * as stockMovements from "../stockMovements.js";
import type * as subscriptionPlans from "../subscriptionPlans.js";
import type * as suppliers from "../suppliers.js";
import type * as templates from "../templates.js";
import type * as tenants from "../tenants.js";
import type * as tokoCat from "../tokoCat.js";
import type * as units from "../units.js";
import type * as users from "../users.js";
import type * as vouchers from "../vouchers.js";
import type * as waste from "../waste.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  admin: typeof admin;
  auditLogs: typeof auditLogs;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  bakery: typeof bakery;
  bengkel: typeof bengkel;
  bomRecipe: typeof bomRecipe;
  brands: typeof brands;
  cafeResto: typeof cafeResto;
  categories: typeof categories;
  clothing: typeof clothing;
  customers: typeof customers;
  expenses: typeof expenses;
  featureFlags: typeof featureFlags;
  http: typeof http;
  kain: typeof kain;
  landingContent: typeof landingContent;
  midtrans: typeof midtrans;
  orders: typeof orders;
  platformSettings: typeof platformSettings;
  posShifts: typeof posShifts;
  products: typeof products;
  purchaseOrders: typeof purchaseOrders;
  reports: typeof reports;
  seed: typeof seed;
  seedDemo: typeof seedDemo;
  shipping: typeof shipping;
  spa: typeof spa;
  sparepart: typeof sparepart;
  staff: typeof staff;
  stockMovements: typeof stockMovements;
  subscriptionPlans: typeof subscriptionPlans;
  suppliers: typeof suppliers;
  templates: typeof templates;
  tenants: typeof tenants;
  tokoCat: typeof tokoCat;
  units: typeof units;
  users: typeof users;
  vouchers: typeof vouchers;
  waste: typeof waste;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
